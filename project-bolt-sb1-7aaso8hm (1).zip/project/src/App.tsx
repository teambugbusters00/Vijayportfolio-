import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Skills from './components/Skills';
import Projects from './components/Projects';
import Certifications from './components/Certifications';
import Contact from './components/Contact';
import Footer from './components/Footer';
import AdminPanel from './components/AdminPanel';
import ParticleBackground from './components/ParticleBackground';
import { AuthProvider } from './context/AuthContext';
import { ContentProvider } from './context/ContentContext';

function App() {
  const [darkMode, setDarkMode] = useState(true);
  const [showAdminPanel, setShowAdminPanel] = useState(false);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // Admin panel toggle with keyboard shortcut (Ctrl+Shift+A)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.shiftKey && e.key === 'A') {
        setShowAdminPanel(!showAdminPanel);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [showAdminPanel]);

  return (
    <AuthProvider>
      <ContentProvider>
        <div className={`min-h-screen transition-colors duration-300 ${
          darkMode ? 'dark bg-gray-900' : 'bg-gray-50'
        }`}>
          <ParticleBackground />
          
          <AnimatePresence>
            {showAdminPanel && (
              <AdminPanel onClose={() => setShowAdminPanel(false)} />
            )}
          </AnimatePresence>

          <Navbar darkMode={darkMode} setDarkMode={setDarkMode} />
          
          <main className="relative z-10">
            <Hero />
            <About />
            <Skills />
            <Projects />
            <Certifications />
            <Contact />
          </main>
          
          <Footer />
        </div>
      </ContentProvider>
    </AuthProvider>
  );
}

export default App;