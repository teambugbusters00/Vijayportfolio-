import React, { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';

interface Project {
  title: string;
  description: string;
  technologies: string[];
  githubUrl: string;
  liveUrl: string;
}

interface SkillGroup {
  category: string;
  skills: string[];
  color: string;
}

interface Certification {
  title: string;
  issuer: string;
  date: string;
  credentialId: string;
  link: string;
}

interface ContentContextType {
  projects: Project[];
  skills: SkillGroup[];
  certifications: Certification[];
  isAdmin: boolean;
  addProject: (project: Project) => void;
  updateProject: (id: number, project: Project) => void;
  deleteProject: (id: number) => void;
  addSkill: (skill: SkillGroup) => void;
  updateSkill: (id: number, skill: SkillGroup) => void;
  deleteSkill: (id: number) => void;
  addCertification: (cert: Certification) => void;
  updateCertification: (id: number, cert: Certification) => void;
  deleteCertification: (id: number) => void;
}

const ContentContext = createContext<ContentContextType | undefined>(undefined);

export const ContentProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isAuthenticated } = useAuth();
  const [projects, setProjects] = useState<Project[]>([]);
  const [skills, setSkills] = useState<SkillGroup[]>([]);
  const [certifications, setCertifications] = useState<Certification[]>([]);

  // Load data from localStorage on mount
  useEffect(() => {
    const savedProjects = localStorage.getItem('portfolio_projects');
    const savedSkills = localStorage.getItem('portfolio_skills');
    const savedCertifications = localStorage.getItem('portfolio_certifications');

    if (savedProjects) setProjects(JSON.parse(savedProjects));
    if (savedSkills) setSkills(JSON.parse(savedSkills));
    if (savedCertifications) setCertifications(JSON.parse(savedCertifications));
  }, []);

  // Save to localStorage whenever data changes
  const saveToStorage = (key: string, data: any) => {
    localStorage.setItem(key, JSON.stringify(data));
  };

  // Project management
  const addProject = (project: Project) => {
    const newProjects = [...projects, project];
    setProjects(newProjects);
    saveToStorage('portfolio_projects', newProjects);
  };

  const updateProject = (id: number, project: Project) => {
    const newProjects = [...projects];
    newProjects[id] = project;
    setProjects(newProjects);
    saveToStorage('portfolio_projects', newProjects);
  };

  const deleteProject = (id: number) => {
    const newProjects = projects.filter((_, index) => index !== id);
    setProjects(newProjects);
    saveToStorage('portfolio_projects', newProjects);
  };

  // Skill management
  const addSkill = (skill: SkillGroup) => {
    const newSkills = [...skills, skill];
    setSkills(newSkills);
    saveToStorage('portfolio_skills', newSkills);
  };

  const updateSkill = (id: number, skill: SkillGroup) => {
    const newSkills = [...skills];
    newSkills[id] = skill;
    setSkills(newSkills);
    saveToStorage('portfolio_skills', newSkills);
  };

  const deleteSkill = (id: number) => {
    const newSkills = skills.filter((_, index) => index !== id);
    setSkills(newSkills);
    saveToStorage('portfolio_skills', newSkills);
  };

  // Certification management
  const addCertification = (cert: Certification) => {
    const newCertifications = [...certifications, cert];
    setCertifications(newCertifications);
    saveToStorage('portfolio_certifications', newCertifications);
  };

  const updateCertification = (id: number, cert: Certification) => {
    const newCertifications = [...certifications];
    newCertifications[id] = cert;
    setCertifications(newCertifications);
    saveToStorage('portfolio_certifications', newCertifications);
  };

  const deleteCertification = (id: number) => {
    const newCertifications = certifications.filter((_, index) => index !== id);
    setCertifications(newCertifications);
    saveToStorage('portfolio_certifications', newCertifications);
  };

  return (
    <ContentContext.Provider
      value={{
        projects,
        skills,
        certifications,
        isAdmin: isAuthenticated,
        addProject,
        updateProject,
        deleteProject,
        addSkill,
        updateSkill,
        deleteSkill,
        addCertification,
        updateCertification,
        deleteCertification,
      }}
    >
      {children}
    </ContentContext.Provider>
  );
};

export const useContent = () => {
  const context = useContext(ContentContext);
  if (context === undefined) {
    throw new Error('useContent must be used within a ContentProvider');
  }
  return context;
};