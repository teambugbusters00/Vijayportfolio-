import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ChevronDown, Download, Github, Linkedin, Instagram } from 'lucide-react';

const Hero: React.FC = () => {
  const [currentTitle, setCurrentTitle] = useState(0);
  const [displayText, setDisplayText] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);

  const titles = [
    "Full-Stack MERN Developer",
    "AI/ML - Deep Learning & NLP",
    "Generative AI & LangChain Explorer",
    "Web3 & Blockchain Enthusiast",
    "Founder – Ziron AI Labs"
  ];

  useEffect(() => {
    const currentTitleText = titles[currentTitle];
    const typeSpeed = isDeleting ? 50 : 100;
    const pauseDelay = isDeleting ? 500 : 2000;

    const timeout = setTimeout(() => {
      if (!isDeleting && displayText === currentTitleText) {
        setTimeout(() => setIsDeleting(true), pauseDelay);
      } else if (isDeleting && displayText === '') {
        setIsDeleting(false);
        setCurrentTitle((prev) => (prev + 1) % titles.length);
      } else {
        setDisplayText(prev => 
          isDeleting 
            ? prev.slice(0, -1)
            : currentTitleText.slice(0, prev.length + 1)
        );
      }
    }, typeSpeed);

    return () => clearTimeout(timeout);
  }, [displayText, isDeleting, currentTitle, titles]);

  const handleDownloadResume = () => {
    // Direct link to Google Drive resume
    window.open('https://drive.google.com/file/d/1Ia3fuU3fuBBleKdg7ApbACQJEgqnE4yi/view?usp=drivesdk', '_blank');
  };

  return (
    <section id="hero" className="min-h-screen flex items-center justify-center relative overflow-hidden">
      {/* Animated Background Grid */}
      <div className="absolute inset-0 bg-cyber-grid bg-cyber-grid opacity-20"></div>
      
      <div className="container mx-auto px-4 text-center relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl mx-auto"
        >
          {/* Name and Alias */}
          <motion.h1 
            className="text-5xl md:text-7xl font-cyber font-bold mb-4"
            initial={{ scale: 0.8 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <span className="cyber-text">VIJAY RAMDEV</span>
          </motion.h1>
          
          <motion.p 
            className="text-2xl md:text-3xl font-tech text-primary-400 mb-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
          >
            (BUG BUSTERS)
          </motion.p>

          {/* Tagline */}
          <motion.div 
            className="text-xl md:text-2xl font-tech text-accent-400 mb-8 flex items-center justify-center space-x-4"
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.6 }}
          >
            <span>Reboot</span>
            <ChevronDown className="rotate-[-90deg] text-primary-500" />
            <span>Rebuilt</span>
            <ChevronDown className="rotate-[-90deg] text-primary-500" />
            <span>Reveal</span>
          </motion.div>

          {/* Typewriter Effect */}
          <motion.div 
            className="h-16 mb-12"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8 }}
          >
            <span className="text-2xl md:text-3xl font-tech text-white">
              {displayText}
              <span className="animate-pulse text-primary-500">|</span>
            </span>
          </motion.div>

          {/* CTA Buttons */}
          <motion.div 
            className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1 }}
          >
            <button 
              onClick={() => document.querySelector('#projects')?.scrollIntoView({ behavior: 'smooth' })}
              className="btn-cyber px-8 py-4"
            >
              View My Work
            </button>
            <button 
              onClick={handleDownloadResume}
              className="flex items-center space-x-2 px-8 py-4 bg-secondary-600 hover:bg-secondary-700 text-white rounded-lg transition-colors font-tech"
            >
              <Download size={20} />
              <span>Download Resume</span>
            </button>
          </motion.div>

          {/* Social Links */}
          <motion.div 
            className="flex justify-center space-x-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.2 }}
          >
            <motion.a
              href="https://github.com/teambugbusters00"
              target="_blank"
              rel="noopener noreferrer"
              whileHover={{ scale: 1.2, y: -5 }}
              className="p-3 rounded-full bg-primary-500/20 text-primary-500 hover:bg-primary-500 hover:text-black transition-all duration-300"
            >
              <Github size={24} />
            </motion.a>
            <motion.a
              href="https://www.linkedin.com/in/vijay-jangid-471a03184"
              target="_blank"
              rel="noopener noreferrer"
              whileHover={{ scale: 1.2, y: -5 }}
              className="p-3 rounded-full bg-primary-500/20 text-primary-500 hover:bg-primary-500 hover:text-black transition-all duration-300"
            >
              <Linkedin size={24} />
            </motion.a>
            <motion.a
              href="https://www.instagram.com/__vijay_jangid_?igsh=N3NwNDhkb3pqMmxx"
              target="_blank"
              rel="noopener noreferrer"
              whileHover={{ scale: 1.2, y: -5 }}
              className="p-3 rounded-full bg-primary-500/20 text-primary-500 hover:bg-primary-500 hover:text-black transition-all duration-300"
            >
              <Instagram size={24} />
            </motion.a>
          </motion.div>
        </motion.div>

        {/* Scroll Indicator */}
        <motion.div 
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
          animate={{ y: [0, 10, 0] }}
          transition={{ repeat: Infinity, duration: 2 }}
        >
          <ChevronDown className="text-primary-500" size={32} />
        </motion.div>
      </div>
    </section>
  );
};

export default Hero;