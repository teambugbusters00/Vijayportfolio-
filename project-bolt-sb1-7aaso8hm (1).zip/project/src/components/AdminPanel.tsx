import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Lock, Settings, Database, Plus, Edit, Trash2, Save } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useContent } from '../context/ContentContext';

interface AdminPanelProps {
  onClose: () => void;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ onClose }) => {
  const { isAuthenticated, login, logout } = useAuth();
  const { projects, skills, certifications, addProject, updateProject, deleteProject } = useContent();
  const [activeTab, setActiveTab] = useState<'projects' | 'skills' | 'certifications'>('projects');
  const [credentials, setCredentials] = useState({ username: '', password: '' });
  const [editingItem, setEditingItem] = useState<any>(null);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Simple authentication - in production, use proper authentication
    if (credentials.username === 'admin' && credentials.password === 'vijay2025') {
      login();
    } else {
      alert('Invalid credentials');
    }
  };

  const handleSaveProject = (projectData: any) => {
    if (editingItem?.id) {
      updateProject(editingItem.id, projectData);
    } else {
      addProject(projectData);
    }
    setEditingItem(null);
  };

  if (!isAuthenticated) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center"
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="bg-gray-900 border border-primary-500/30 rounded-xl p-8 max-w-md w-full mx-4"
        >
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-2">
              <Lock className="text-primary-500" size={24} />
              <h2 className="text-xl font-cyber font-bold text-white">Admin Access</h2>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-white transition-colors"
            >
              <X size={24} />
            </button>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-sm font-tech text-gray-300 mb-2">Username</label>
              <input
                type="text"
                value={credentials.username}
                onChange={(e) => setCredentials({...credentials, username: e.target.value})}
                className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white font-tech focus:outline-none focus:border-primary-500"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-tech text-gray-300 mb-2">Password</label>
              <input
                type="password"
                value={credentials.password}
                onChange={(e) => setCredentials({...credentials, password: e.target.value})}
                className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white font-tech focus:outline-none focus:border-primary-500"
                required
              />
            </div>
            <button
              type="submit"
              className="w-full btn-cyber py-3"
            >
              Login
            </button>
          </form>
        </motion.div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-gray-900 border border-primary-500/30 rounded-xl max-w-6xl w-full max-h-[80vh] overflow-hidden"
      >
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-800">
          <div className="flex items-center space-x-2">
            <Settings className="text-primary-500" size={24} />
            <h2 className="text-xl font-cyber font-bold text-white">Admin Panel</h2>
          </div>
          <div className="flex items-center space-x-4">
            <button
              onClick={logout}
              className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg font-tech transition-colors"
            >
              Logout
            </button>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-white transition-colors"
            >
              <X size={24} />
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-gray-800">
          {['projects', 'skills', 'certifications'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab as any)}
              className={`px-6 py-4 font-tech capitalize transition-colors ${
                activeTab === tab
                  ? 'text-primary-400 border-b-2 border-primary-500 bg-primary-500/10'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="p-6 max-h-[60vh] overflow-y-auto">
          {activeTab === 'projects' && (
            <div>
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-cyber font-bold text-white">Manage Projects</h3>
                <button
                  onClick={() => setEditingItem({})}
                  className="flex items-center space-x-2 px-4 py-2 bg-primary-600 hover:bg-primary-700 text-white rounded-lg font-tech transition-colors"
                >
                  <Plus size={16} />
                  <span>Add Project</span>
                </button>
              </div>

              <div className="grid gap-4">
                {projects.map((project, index) => (
                  <div key={index} className="bg-gray-800 p-4 rounded-lg border border-gray-700">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-tech font-bold text-white">{project.title}</h4>
                        <p className="text-gray-400 text-sm">{project.description}</p>
                      </div>
                      <div className="flex space-x-2">
                        <button
                          onClick={() => setEditingItem({...project, id: index})}
                          className="p-2 text-blue-400 hover:text-blue-300 transition-colors"
                        >
                          <Edit size={16} />
                        </button>
                        <button
                          onClick={() => deleteProject(index)}
                          className="p-2 text-red-400 hover:text-red-300 transition-colors"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Edit Form Modal */}
          <AnimatePresence>
            {editingItem && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 bg-black/80 flex items-center justify-center z-50"
              >
                <motion.div
                  initial={{ scale: 0.9 }}
                  animate={{ scale: 1 }}
                  exit={{ scale: 0.9 }}
                  className="bg-gray-900 p-6 rounded-xl border border-primary-500/30 max-w-2xl w-full mx-4 max-h-[80vh] overflow-y-auto"
                >
                  <h3 className="text-lg font-cyber font-bold text-white mb-4">
                    {editingItem.id !== undefined ? 'Edit Project' : 'Add Project'}
                  </h3>
                  
                  <ProjectForm
                    project={editingItem}
                    onSave={handleSaveProject}
                    onCancel={() => setEditingItem(null)}
                  />
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    </motion.div>
  );
};

// Project Form Component
const ProjectForm: React.FC<{
  project: any;
  onSave: (project: any) => void;
  onCancel: () => void;
}> = ({ project, onSave, onCancel }) => {
  const [formData, setFormData] = useState({
    title: project.title || '',
    description: project.description || '',
    technologies: project.technologies?.join(', ') || '',
    githubUrl: project.githubUrl || '',
    liveUrl: project.liveUrl || ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      ...formData,
      technologies: formData.technologies.split(',').map(tech => tech.trim())
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-tech text-gray-300 mb-2">Title</label>
        <input
          type="text"
          value={formData.title}
          onChange={(e) => setFormData({...formData, title: e.target.value})}
          className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white font-tech focus:outline-none focus:border-primary-500"
          required
        />
      </div>
      
      <div>
        <label className="block text-sm font-tech text-gray-300 mb-2">Description</label>
        <textarea
          value={formData.description}
          onChange={(e) => setFormData({...formData, description: e.target.value})}
          className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white font-tech focus:outline-none focus:border-primary-500"
          rows={3}
          required
        />
      </div>
      
      <div>
        <label className="block text-sm font-tech text-gray-300 mb-2">Technologies (comma-separated)</label>
        <input
          type="text"
          value={formData.technologies}
          onChange={(e) => setFormData({...formData, technologies: e.target.value})}
          className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white font-tech focus:outline-none focus:border-primary-500"
          placeholder="React, Node.js, MongoDB"
        />
      </div>
      
      <div className="grid md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-tech text-gray-300 mb-2">GitHub URL</label>
          <input
            type="url"
            value={formData.githubUrl}
            onChange={(e) => setFormData({...formData, githubUrl: e.target.value})}
            className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white font-tech focus:outline-none focus:border-primary-500"
          />
        </div>
        
        <div>
          <label className="block text-sm font-tech text-gray-300 mb-2">Live URL</label>
          <input
            type="url"
            value={formData.liveUrl}
            onChange={(e) => setFormData({...formData, liveUrl: e.target.value})}
            className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white font-tech focus:outline-none focus:border-primary-500"
          />
        </div>
      </div>
      
      <div className="flex space-x-4 pt-4">
        <button
          type="submit"
          className="flex items-center space-x-2 px-6 py-3 bg-primary-600 hover:bg-primary-700 text-white rounded-lg font-tech transition-colors"
        >
          <Save size={16} />
          <span>Save</span>
        </button>
        <button
          type="button"
          onClick={onCancel}
          className="px-6 py-3 bg-gray-700 hover:bg-gray-600 text-white rounded-lg font-tech transition-colors"
        >
          Cancel
        </button>
      </div>
    </form>
  );
};

export default AdminPanel;