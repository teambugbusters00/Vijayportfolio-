import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { useContent } from '../context/ContentContext';

const Skills: React.FC = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.2,
  });

  const { skills, isAdmin } = useContent();

  const defaultSkills = [
    {
      category: "Languages",
      skills: ["Python", "C", "JavaScript"],
      color: "from-red-500 to-pink-500"
    },
    {
      category: "Frontend",
      skills: ["React.js", "Tailwind CSS", "Bootstrap", "HTML", "CSS"],
      color: "from-blue-500 to-cyan-500"
    },
    {
      category: "Backend",
      skills: ["Node.js", "Express.js"],
      color: "from-green-500 to-emerald-500"
    },
    {
      category: "Databases",
      skills: ["MySQL"],
      color: "from-yellow-500 to-orange-500"
    },
    {
      category: "AI/ML",
      skills: ["OpenAI API", "Gemini", "Vertex AI", "Streamlit", "LangChain", "NLP", "Deep Learning"],
      color: "from-purple-500 to-violet-500"
    },
    {
      category: "DevOps",
      skills: ["Docker", "Kubernetes", "Git", "GitHub"],
      color: "from-indigo-500 to-blue-500"
    },
    {
      category: "Web3 & Blockchain",
      skills: ["Smart contracts", "dApps (exploring)"],
      color: "from-pink-500 to-rose-500"
    }
  ];

  const skillsToShow = skills.length > 0 ? skills : defaultSkills;

  return (
    <section id="skills" className="py-20 relative">
      <div className="container mx-auto px-4" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="section-title">Skills & Tech Stack</h2>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          {skillsToShow.map((skillGroup, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={inView ? { opacity: 1, scale: 1 } : {}}
              transition={{ delay: index * 0.1 }}
              whileHover={{ scale: 1.05, y: -10 }}
              className="card-cyber group"
            >
              <div className={`h-2 w-full bg-gradient-to-r ${skillGroup.color} rounded-full mb-4`}></div>
              
              <h3 className="text-xl font-cyber font-bold text-white mb-4 group-hover:text-primary-400 transition-colors">
                {skillGroup.category}
              </h3>
              
              <div className="space-y-2">
                {skillGroup.skills.map((skill, skillIndex) => (
                  <motion.div
                    key={skillIndex}
                    initial={{ opacity: 0, x: -20 }}
                    animate={inView ? { opacity: 1, x: 0 } : {}}
                    transition={{ delay: (index * 0.1) + (skillIndex * 0.05) }}
                    className="flex items-center space-x-2"
                  >
                    <div className="w-2 h-2 bg-primary-500 rounded-full animate-pulse"></div>
                    <span className="text-gray-300 font-tech text-sm hover:text-primary-400 transition-colors">
                      {skill}
                    </span>
                  </motion.div>
                ))}
              </div>

              {isAdmin && (
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.95 }}
                  className="mt-4 px-3 py-1 bg-accent-500/20 text-accent-400 rounded text-xs font-tech border border-accent-500/30 hover:bg-accent-500/30 transition-colors"
                  onClick={() => {
                    // Edit skill functionality - will be implemented in admin panel
                  }}
                >
                  Edit Skills
                </motion.button>
              )}
            </motion.div>
          ))}
        </div>

        <motion.div 
          className="text-center mt-12"
          initial={{ opacity: 0 }}
          animate={inView ? { opacity: 1 } : {}}
          transition={{ delay: 0.8 }}
        >
          <p className="text-gray-400 font-tech">
            Always learning and exploring new technologies to stay ahead of the curve
          </p>
        </motion.div>
      </div>
    </section>
  );
};

export default Skills;