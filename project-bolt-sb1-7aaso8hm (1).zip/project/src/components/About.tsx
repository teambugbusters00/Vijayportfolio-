import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Code, Zap, Rocket, Brain } from 'lucide-react';

const About: React.FC = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.2,
  });

  const features = [
    {
      icon: <Code className="w-8 h-8" />,
      title: "Full-Stack Development",
      description: "MERN stack expertise with modern frameworks"
    },
    {
      icon: <Brain className="w-8 h-8" />,
      title: "AI/ML Innovation",
      description: "Advanced AI solutions with LangChain & OpenAI"
    },
    {
      icon: <Rocket className="w-8 h-8" />,
      title: "Ziron AI Labs",
      description: "Leading innovation in intelligent systems"
    },
    {
      icon: <Zap className="w-8 h-8" />,
      title: "Web3 & Blockchain",
      description: "Exploring decentralized technologies"
    }
  ];

  return (
    <section id="about" className="py-20 relative">
      <div className="container mx-auto px-4" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="section-title">About Me</h2>
          <div className="max-w-4xl mx-auto">
            <motion.blockquote 
              className="text-xl italic text-primary-400 mb-8 border-l-4 border-primary-500 pl-6"
              initial={{ opacity: 0, x: -50 }}
              animate={inView ? { opacity: 1, x: 0 } : {}}
              transition={{ delay: 0.3 }}
            >
              "This site is a reflection of my skills, creativity, and dedication to web development. 
              Built using HTML & CSS in just 2 hours, it illustrates my passion for building 
              functional, elegant digital experiences."
            </motion.blockquote>
            
            <motion.p 
              className="text-lg text-gray-300 leading-relaxed font-tech"
              initial={{ opacity: 0 }}
              animate={inView ? { opacity: 1 } : {}}
              transition={{ delay: 0.5 }}
            >
              I'm a full-stack MERN developer and AI/ML enthusiast with a love for futuristic, 
              intelligent systems. From generative AI to civic bots and blockchain tech, I lead 
              innovation with <span className="cyber-text font-semibold">Ziron AI Labs</span>. 
              My journey blends real-world challenges with advanced tech like Gemini, Streamlit, 
              LangChain, and Dockerized apps. Currently exploring the power of Web3 and 
              decentralized intelligence.
            </motion.p>
          </div>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.7 + index * 0.1 }}
              whileHover={{ scale: 1.05, y: -10 }}
              className="card-cyber text-center group"
            >
              <div className="text-primary-500 mb-4 flex justify-center group-hover:text-accent-400 transition-colors">
                {feature.icon}
              </div>
              <h3 className="text-xl font-cyber font-bold text-white mb-3">
                {feature.title}
              </h3>
              <p className="text-gray-400 font-tech">
                {feature.description}
              </p>
            </motion.div>
          ))}
        </div>

        <motion.div 
          className="text-center mt-16"
          initial={{ opacity: 0 }}
          animate={inView ? { opacity: 1 } : {}}
          transition={{ delay: 1.1 }}
        >
          <div className="inline-flex items-center space-x-4 bg-gradient-to-r from-primary-500/20 to-secondary-500/20 rounded-full px-6 py-3 border border-primary-500/30">
            <span className="text-primary-400 font-tech">📍</span>
            <span className="text-white font-tech">Jodhpur, Rajasthan, India</span>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default About;