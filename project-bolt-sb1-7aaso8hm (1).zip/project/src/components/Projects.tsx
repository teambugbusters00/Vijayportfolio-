import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Github, ExternalLink, Calendar, Star } from 'lucide-react';
import { useContent } from '../context/ContentContext';

interface GitHubRepo {
  id: number;
  name: string;
  description: string;
  html_url: string;
  homepage: string;
  language: string;
  stargazers_count: number;
  updated_at: string;
  topics: string[];
}

const Projects: React.FC = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.2,
  });

  const { projects, isAdmin } = useContent();
  const [githubRepos, setGithubRepos] = useState<GitHubRepo[]>([]);
  const [loading, setLoading] = useState(true);

  const defaultProjects = [
    {
      title: "Gemini Voice Assistant",
      description: "Voice-controlled desktop app with weather, email, calendar, and OpenAI integration.",
      technologies: ["Python", "OpenAI API", "Gemini", "Voice Recognition"],
      githubUrl: "https://github.com/teambugbusters00",
      liveUrl: "#"
    },
    {
      title: "YONO-style Banking System",
      description: "GUI banking clone with complete login system, dashboard & full user flow.",
      technologies: ["Python", "Tkinter", "MySQL", "GUI"],
      githubUrl: "https://github.com/teambugbusters00",
      liveUrl: "#"
    },
    {
      title: "Student Data Manager",
      description: "Python GUI application for managing multi-student records with data validations.",
      technologies: ["Python", "Tkinter", "Database", "Data Validation"],
      githubUrl: "https://github.com/teambugbusters00",
      liveUrl: "#"
    },
    {
      title: "WhatsApp Emotional AI Bot",
      description: "Emotion-aware chatbot for WhatsApp Cloud API with sentiment analysis.",
      technologies: ["Python", "WhatsApp API", "NLP", "Sentiment Analysis"],
      githubUrl: "https://github.com/teambugbusters00",
      liveUrl: "#"
    },
    {
      title: "Virtual Cultural Tour",
      description: "Immersive website for exploring Indian heritage with interactive elements.",
      technologies: ["React.js", "CSS", "JavaScript", "3D Graphics"],
      githubUrl: "https://github.com/teambugbusters00",
      liveUrl: "#"
    },
    {
      title: "CIVIGUARD",
      description: "Civic grievance prediction platform using AI agents for smart city solutions.",
      technologies: ["Python", "AI/ML", "LangChain", "Data Analytics"],
      githubUrl: "https://github.com/teambugbusters00",
      liveUrl: "#"
    },
    {
      title: "Heartbeat Monitoring Device",
      description: "Python + hardware project for real-time health monitoring and alerts.",
      technologies: ["Python", "Hardware", "IoT", "Health Tech"],
      githubUrl: "https://github.com/teambugbusters00",
      liveUrl: "#"
    }
  ];

  useEffect(() => {
    const fetchGitHubRepos = async () => {
      try {
        const response = await fetch('https://api.github.com/users/teambugbusters00/repos?sort=updated&per_page=20');
        if (response.ok) {
          const repos = await response.json();
          setGithubRepos(repos);
        }
      } catch (error) {
        console.error('Failed to fetch GitHub repos:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchGitHubRepos();
  }, []);

  const projectsToShow = projects.length > 0 ? projects : defaultProjects;

  return (
    <section id="projects" className="py-20 relative">
      <div className="container mx-auto px-4" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="section-title">Featured Projects</h2>
          <p className="text-gray-400 font-tech max-w-2xl mx-auto">
            Explore my latest work combining AI/ML, full-stack development, and innovative solutions
          </p>
        </motion.div>

        {/* GitHub Stats */}
        {!loading && githubRepos.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.3 }}
            className="text-center mb-12"
          >
            <div className="inline-flex items-center space-x-6 bg-gradient-to-r from-primary-500/20 to-secondary-500/20 rounded-full px-6 py-3 border border-primary-500/30">
              <div className="flex items-center space-x-2">
                <Github className="text-primary-400" size={20} />
                <span className="text-white font-tech">{githubRepos.length} Repositories</span>
              </div>
              <div className="flex items-center space-x-2">
                <Star className="text-accent-400" size={20} />
                <span className="text-white font-tech">
                  {githubRepos.reduce((acc, repo) => acc + repo.stargazers_count, 0)} Stars
                </span>
              </div>
            </div>
          </motion.div>
        )}

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projectsToShow.map((project, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: index * 0.1 }}
              whileHover={{ scale: 1.03, y: -10 }}
              className="card-cyber group relative overflow-hidden"
            >
              {/* Project Header */}
              <div className="mb-4">
                <h3 className="text-xl font-cyber font-bold text-white mb-2 group-hover:text-primary-400 transition-colors">
                  {project.title}
                </h3>
                <p className="text-gray-400 font-tech text-sm leading-relaxed">
                  {project.description}
                </p>
              </div>

              {/* Technologies */}
              <div className="mb-4">
                <div className="flex flex-wrap gap-2">
                  {project.technologies?.map((tech, techIndex) => (
                    <span
                      key={techIndex}
                      className="px-2 py-1 bg-primary-500/20 text-primary-400 text-xs rounded-full border border-primary-500/30 font-tech"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>

              {/* Project Links */}
              <div className="flex items-center justify-between mt-auto">
                <div className="flex space-x-3">
                  <motion.a
                    href={project.githubUrl || "https://github.com/teambugbusters00"}
                    target="_blank"
                    rel="noopener noreferrer"
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.95 }}
                    className="p-2 bg-gray-800 rounded-lg text-gray-400 hover:text-primary-500 hover:bg-gray-700 transition-all"
                  >
                    <Github size={18} />
                  </motion.a>
                  {project.liveUrl && project.liveUrl !== "#" && (
                    <motion.a
                      href={project.liveUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.95 }}
                      className="p-2 bg-gray-800 rounded-lg text-gray-400 hover:text-accent-500 hover:bg-gray-700 transition-all"
                    >
                      <ExternalLink size={18} />
                    </motion.a>
                  )}
                </div>

                {isAdmin && (
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.95 }}
                    className="px-3 py-1 bg-accent-500/20 text-accent-400 rounded text-xs font-tech border border-accent-500/30 hover:bg-accent-500/30 transition-colors"
                    onClick={() => {
                      // Edit project functionality
                    }}
                  >
                    Edit
                  </motion.button>
                )}
              </div>

              {/* Hover Effect Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-primary-500/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"></div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={inView ? { opacity: 1 } : {}}
          transition={{ delay: 0.8 }}
          className="text-center mt-12"
        >
          <motion.a
            href="https://github.com/teambugbusters00"
            target="_blank"
            rel="noopener noreferrer"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="btn-cyber inline-flex items-center space-x-2"
          >
            <Github size={20} />
            <span>View All Projects on GitHub</span>
          </motion.a>
        </motion.div>
      </div>
    </section>
  );
};

export default Projects;