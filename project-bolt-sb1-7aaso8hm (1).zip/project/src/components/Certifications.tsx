import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Award, Calendar, ExternalLink, FolderOpen } from 'lucide-react';
import { useContent } from '../context/ContentContext';

const Certifications: React.FC = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.2,
  });

  const { certifications, isAdmin } = useContent();

  const defaultCertifications = [
    {
      title: "Fullstack MERN Certified",
      issuer: "Underrated Coder",
      date: "May 2025",
      credentialId: "UCFSDB0604",
      link: "https://drive.google.com/drive/folders/1Id9KF1v0mjSQ6iJniRA2B204g_Hyy6GR"
    },
    {
      title: "Inspect Rich Documents with Gemini & RAG",
      issuer: "Google",
      date: "May 2025",
      credentialId: "Show Credential",
      link: "https://drive.google.com/drive/folders/1Id9KF1v0mjSQ6iJniRA2B204g_Hyy6GR"
    },
    {
      title: "Prompt Design in Vertex AI",
      issuer: "Google",
      date: "May 2025",
      credentialId: "Show Credential",
      link: "https://drive.google.com/drive/folders/1Id9KF1v0mjSQ6iJniRA2B204g_Hyy6GR"
    },
    {
      title: "Vibe-a-thon (Hackathon Participation)",
      issuer: "GEEKROOM IGC",
      date: "May 2025",
      credentialId: "—",
      link: "https://drive.google.com/drive/folders/1Id9KF1v0mjSQ6iJniRA2B204g_Hyy6GR"
    },
    {
      title: "Infosys C Programming Course",
      issuer: "Infosys Springboard",
      date: "Nov 2024",
      credentialId: "Strengthened foundation in C",
      link: "https://drive.google.com/drive/folders/1Id9KF1v0mjSQ6iJniRA2B204g_Hyy6GR"
    },
    {
      title: "Domestic Data Entry Operator",
      issuer: "RSLDC, Govt. of Rajasthan",
      date: "Apr 2024",
      credentialId: "Office Assistant, IT Skills",
      link: "https://drive.google.com/drive/folders/1Id9KF1v0mjSQ6iJniRA2B204g_Hyy6GR"
    },
    {
      title: "Docker & Kubernetes Basics",
      issuer: "Scaler School of Tech",
      date: "Jun 2025",
      credentialId: "Docker & K8s Skills",
      link: "https://drive.google.com/drive/folders/1Id9KF1v0mjSQ6iJniRA2B204g_Hyy6GR"
    },
    {
      title: "Generative AI Courses",
      issuer: "Gen AI Academy",
      date: "Jun 2025",
      credentialId: "2025H2S04GENAI-A100319",
      link: "https://drive.google.com/drive/folders/1Id9KF1v0mjSQ6iJniRA2B204g_Hyy6GR"
    },
    {
      title: "Build AI Apps with Gemini & Imagen",
      issuer: "Google",
      date: "May 2025",
      credentialId: "Show Credential",
      link: "https://drive.google.com/drive/folders/1Id9KF1v0mjSQ6iJniRA2B204g_Hyy6GR"
    },
    {
      title: "Develop GenAI Apps w/ Streamlit",
      issuer: "Google",
      date: "May 2025",
      credentialId: "Show Credential",
      link: "https://drive.google.com/drive/folders/1Id9KF1v0mjSQ6iJniRA2B204g_Hyy6GR"
    },
    {
      title: "Explore Generative AI w/ Vertex API",
      issuer: "Google",
      date: "May 2025",
      credentialId: "Show Credential",
      link: "https://drive.google.com/drive/folders/1Id9KF1v0mjSQ6iJniRA2B204g_Hyy6GR"
    }
  ];

  const certificationsToShow = certifications.length > 0 ? certifications : defaultCertifications;

  const handleViewAllCertifications = () => {
    window.open('https://drive.google.com/drive/folders/1Id9KF1v0mjSQ6iJniRA2B204g_Hyy6GR', '_blank');
  };

  return (
    <section id="certifications" className="py-20 relative">
      <div className="container mx-auto px-4" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="section-title">Licenses & Certifications</h2>
          <p className="text-gray-400 font-tech max-w-2xl mx-auto mb-8">
            Continuous learning and professional development in cutting-edge technologies
          </p>
          
          {/* View All Certifications Button */}
          <motion.button
            onClick={handleViewAllCertifications}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="inline-flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-accent-500 to-accent-600 text-white rounded-lg font-tech font-semibold hover:from-accent-600 hover:to-accent-700 transition-all duration-300 shadow-lg hover:shadow-accent-500/25"
          >
            <FolderOpen size={20} />
            <span>View All Certifications</span>
          </motion.button>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {certificationsToShow.map((cert, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={inView ? { opacity: 1, scale: 1 } : {}}
              transition={{ delay: index * 0.1 }}
              whileHover={{ scale: 1.03, y: -5 }}
              className="card-cyber group relative"
            >
              {/* Certification Icon */}
              <div className="flex items-start justify-between mb-4">
                <div className="p-3 bg-gradient-to-br from-accent-500/20 to-accent-600/20 rounded-lg">
                  <Award className="text-accent-400 group-hover:text-accent-300 transition-colors" size={24} />
                </div>
                
                {cert.link && (
                  <motion.a
                    href={cert.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.95 }}
                    className="p-2 text-gray-400 hover:text-primary-500 transition-colors"
                  >
                    <ExternalLink size={16} />
                  </motion.a>
                )}
              </div>

              {/* Certification Details */}
              <div className="mb-4">
                <h3 className="text-lg font-cyber font-bold text-white mb-2 group-hover:text-primary-400 transition-colors leading-tight">
                  {cert.title}
                </h3>
                <p className="text-secondary-400 font-tech font-semibold mb-1">
                  {cert.issuer}
                </p>
                <div className="flex items-center space-x-2 text-sm text-gray-400 font-tech">
                  <Calendar size={14} />
                  <span>{cert.date}</span>
                </div>
              </div>

              {/* Credential ID */}
              {cert.credentialId && cert.credentialId !== "—" && (
                <div className="mb-4">
                  <span className="text-xs text-gray-500 font-tech uppercase tracking-wider">
                    Credential ID
                  </span>
                  <p className="text-sm text-primary-400 font-tech font-mono">
                    {cert.credentialId}
                  </p>
                </div>
              )}

              {/* Admin Edit Button */}
              {isAdmin && (
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.95 }}
                  className="absolute top-4 right-12 px-2 py-1 bg-accent-500/20 text-accent-400 rounded text-xs font-tech border border-accent-500/30 hover:bg-accent-500/30 transition-colors"
                  onClick={() => {
                    // Edit certification functionality
                  }}
                >
                  Edit
                </motion.button>
              )}

              {/* Hover Effect */}
              <div className="absolute inset-0 bg-gradient-to-br from-accent-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity rounded-xl pointer-events-none"></div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={inView ? { opacity: 1 } : {}}
          transition={{ delay: 0.8 }}
          className="text-center mt-12"
        >
          <p className="text-gray-400 font-tech">
            Always expanding knowledge and staying current with industry trends
          </p>
        </motion.div>
      </div>
    </section>
  );
};

export default Certifications;