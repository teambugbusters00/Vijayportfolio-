import React from 'react';
import { motion } from 'framer-motion';
import { Heart, Code, Zap } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-black/50 backdrop-blur-lg border-t border-primary-500/30 py-12">
      <div className="container mx-auto px-4">
        <div className="text-center">
          {/* Quote */}
          <motion.blockquote
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-2xl md:text-3xl font-cyber font-bold cyber-text mb-8"
          >
            "Galaxies collapse, I evolve."
          </motion.blockquote>

          {/* Creator Info */}
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="flex flex-col md:flex-row items-center justify-center space-y-2 md:space-y-0 md:space-x-4 text-gray-400 font-tech"
          >
            <div className="flex items-center space-x-2">
              <span>Built & Designed with</span>
              <Heart className="text-red-500 animate-pulse" size={16} />
              <span>by</span>
              <span className="text-primary-400 font-semibold">Vijay Ramdev</span>
            </div>
            <div className="hidden md:block text-gray-600">|</div>
            <div className="flex items-center space-x-2">
              <span>Founder —</span>
              <span className="text-secondary-400 font-semibold">Ziron AI Labs</span>
            </div>
          </motion.div>

          {/* Tech Stack */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="mt-6 flex items-center justify-center space-x-4 text-sm text-gray-500 font-tech"
          >
            <div className="flex items-center space-x-1">
              <Code size={14} />
              <span>React.js</span>
            </div>
            <span>•</span>
            <div className="flex items-center space-x-1">
              <Zap size={14} />
              <span>Tailwind CSS</span>
            </div>
            <span>•</span>
            <span>Framer Motion</span>
          </motion.div>

          {/* Copyright */}
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ delay: 0.7 }}
            className="mt-8 pt-8 border-t border-gray-800 text-sm text-gray-500 font-tech"
          >
            © {new Date().getFullYear()} Vijay Ramdev. All rights reserved. Made with cutting-edge tech for the future.
          </motion.div>

          {/* Admin Panel Hint */}
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ delay: 0.9 }}
            className="mt-4 text-xs text-gray-600 font-tech"
          >
            Press Ctrl+Shift+A for admin access
          </motion.div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;